import Layout from "../components/layout";

const Contact = () => {
  return (
    <Layout>
      <div className="mb-4 ml-4">
        Hi,how can we help you?
        <div className="flex size-72 border">
          I WANT TO KNOW WHERE MY ORDER IS Get status update about your order.
        </div>
      </div>
    </Layout>
  );
};

export default Contact;
