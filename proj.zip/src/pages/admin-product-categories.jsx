import { ProductCategoriesSelect } from "../components/modules/product-categories-select";

const AdminProductCategories = () => {
  return (
    <div>
      CAtegories
      <ProductCategoriesSelect />
    </div>
  );
};

export default AdminProductCategories;
