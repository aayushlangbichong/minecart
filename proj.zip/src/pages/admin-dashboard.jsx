import React from "react";
import AdminLayout from "../components/admin-layout";

const AdminDashboard = () => {
  return <AdminLayout>dashbpardi</AdminLayout>;
};
export default AdminDashboard;
