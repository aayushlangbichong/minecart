import Layout from "../components/layout";

const About = () => {
  return <Layout>They not like us.</Layout>;
};

export default About;
