const NO_IMAGE_URL = "https://www.guttercrest.co.uk/wp-content/uploads/woocommerce-placeholder-600x600.png"

export {NO_IMAGE_URL};